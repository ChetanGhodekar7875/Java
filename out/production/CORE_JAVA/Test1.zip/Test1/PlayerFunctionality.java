package Test1;

public class PlayerFunctionality {
    Player[] players=new Player[5];

    {
        players[0]=new Player(101,"SACHIN",30,"INTERNATIONAL","ONE DAY");
        players[1]=new Player(102,"MSD",50,"NATIONAL","T20");
        players[2]=new Player(103,"VIRAT",77,"INTERNATIONAL","ONE DAY");
        players[3]=new Player(104,"ROHIT",35,"NATIONAL","T20");
        players[4]=new Player(105,"KLRAHUL",34,"INTERNATIONAL","TEST");
    }

    Player findPlayerWithLowestRuns(String pType){
        Player playerCurrentObject=null;
        int minRuns=Integer.MAX_VALUE;
        for(int i=0;i<players.length;i++){
            if(players[i].getPlayerType().equalsIgnoreCase(pType)){
                minRuns=players[i].getRuns();
            }
        }
        for(int i=0;i<players.length;i++){
            if(players[i].getPlayerType().equalsIgnoreCase(pType) && minRuns==players[i].getRuns()){
                playerCurrentObject=players[i];
            }
        }

        return playerCurrentObject;
    }
}
